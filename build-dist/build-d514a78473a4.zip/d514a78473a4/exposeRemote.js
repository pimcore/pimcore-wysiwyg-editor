
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_wysiwyg_editor_bundle = "/bundles/pimcorewysiwygeditor/studio/build/d514a78473a4/static/js/remoteEntry.js"

      window.alternativePluginExportPaths.pimcore_wysiwyg_editor_bundle = "/plugins"
    