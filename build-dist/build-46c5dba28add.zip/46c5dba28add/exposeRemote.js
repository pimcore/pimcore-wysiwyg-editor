
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_wysiwyg_editor_bundle = "/bundles/pimcorewysiwygeditor/studio/build/46c5dba28add/static/js/remoteEntry.js"

      window.alternativePluginExportPaths.pimcore_wysiwyg_editor_bundle = "/plugins"
    